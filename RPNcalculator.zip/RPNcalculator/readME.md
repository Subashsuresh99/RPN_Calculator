\# RPN Calculator with Visual Stack Trace



\*\*A Python-based GUI Calculator using Reverse Polish Notation (RPN)\*\*



---



\##  Authors

\* \*\*Gautam Ramesh\*\* (Matriculation No: 7026787)

\* \*\*Subash Karapparambu Suresh Kumar\*\* (Matriculation No: 7026794)



---



\##  Project Overview

This project is a fully functional \*\*Reverse Polish Notation (RPN) Calculator\*\* built using \*\*Python\*\* and the \*\*Flet\*\* framework. Unlike standard calculators, this application allows users to visualize the \*\*Stack Data Structure\*\* in real-time.



It features a unique \*\*"Step-by-Step Debugger"\*\* mode that lets users type a full expression (e.g., `3 4 + 5 \*`) and execute it one step at a time to understand how RPN logic works under the hood.



\### Key Features

\* \*\*Visual Stack:\*\* Watch numbers get Pushed and Popped from the stack in real-time.

\* \*\*Step-by-Step Execution:\*\* Type a complex equation and step through the logic manually.

\* \*\*Advanced Operations:\*\* Includes `SWAP` (swap top 2 items) and `ROT` (rotate top 3 items).

\* \*\*Keyboard Support:\*\* Fully supports physical keyboard input (Numpad, Enter, Spacebar, Backspace).

\* \*\*Error Handling:\*\* robust protection against Division by Zero and Stack Underflow.



---



\##  Technology Stack

\* \*\*Language:\*\* Python 3.10+

\* \*\*GUI Framework:\*\* \[Flet](https://flet.dev/) (Flutter for Python)

\* \*\*Logic:\*\* List-based Stack (LIFO) implementation



---



\##  Installation \& Setup



\### 1. Prerequisites

Ensure you have Python installed. You can check by running:

```bash

python --version

